# UGGFY.VISION - Portfolio Website

  ## Tech Stack
  React + TypeScript + Vite + Tailwind CSS + Framer Motion

  ## Run Locally
  ```bash
  npm install
  npm run dev
  ```

  ## Build for Production
  ```bash
  npm run build
  # Output goes to dist/ folder
  ```

  ## Deploy on Railway
  1. Push this folder to a GitHub repo
  2. Go to railway.app → New Project → Deploy from GitHub
  3. Select your repo
  4. Railway auto-detects Vite — set build command: `npm run build`
  5. Set start command: `npx serve dist`
  6. Set PORT environment variable if needed
  7. Add your custom domain (UGGFY.vision) in Railway settings → Custom Domain

  ## Customize Your Info
  Edit `src/components/Projects.tsx` to add your real GitHub links.
  Edit `src/components/Contact.tsx` to update email/Telegram/GitHub.
  